import flet as f 
from flet import Image
#colori
def main(page: f.Page):
    page.title = "App30"
    BG = '#041955' #blu scuro
    FWG = '#97b4ff' #ciano
    FG = '#3450a1' #ciano scuro
    theme = f.Theme()
    theme.visual_density = f.ThemeVisualDensity.COMPACT
    page.theme_mode = f.ThemeMode.DARK
    page.window_width = 350        
    page.window_height = 200       
    page.window_resizable = True  
    page.update()
    page.window_width = 600        
    page.window_height = 400       
    page.window_resizable = True  
    page.update()
    page.scroll = "auto"
    page.icon = "icona.png"
    page.update()
    
    def myscroll (e:f.OnScrollEvent):
        print(e)
#funzionamento source bar
    data = [
		{
			"name":"Leggi","where":"/create_task"
		},
		{
			"name":"Gioca","where":"/create_task2"
		},
		{
			"name":"Shop","where":"/create_task3"
		},
		{
			"name":"gioca","where":"/create_task2"
		},
		{
			"name":"Introduzione","where":"/create_task"
		},
		{
			"name":"introduzione","where":"/create_task"
		},
		{
			"name":"Storia","where":"/create_task1"
		},
        {
			"name":"storia","where":"/create_task1"
		},
        {
			"name":"Tipi","where":"/slide_task_2"
		},
        {
			"name":"tipi","where":"/slide_task_2"
		},
        {
			"name":"Energia","where":"/slide_task_2"
		},
        {
			"name":"energia","where":"/slide_task_2"
		},
        {
			"name":"Meccanica","where":"/slide_task_2"
		},
        {
			"name":"meccanica","where":"/slide_task_2"
		},
        {
			"name":"Chimica","where":"/slide_task_2"
		},
        {
			"name":"chimica","where":"/slide_task_2"
		},
        {
			"name":"Elettromagnetica","where":"/slide_task_2"
		},
        {
			"name":"elettromagnetica","where":"/slide_task_2"
		},
        {
			"name":"Gravitazionale","where":"/slide_task_2"
		},
        {
			"name":"gravitazionale","where":"/slide_task_2"
		},
        {
			"name":"Termica","where":"/slide_task_2"
		},
        {
			"name":"termica","where":"/slide_task_2"
		},
        {
			"name":"Nucleare","where":"/slide_task_2"
		},
        {
			"name":"nucleare","where":"/slide_task_2"
		},
        {
			"name":"Impatto","where":"/slide_task_4"
		},
        {
			"name":"impatto","where":"/slide_task_4"
		},
        {
			"name":"Multinazionale","where":"/slide_task_4"
		},
        {
			"name":"multinazionale","where":"/slide_task_4"
		},
        {
			"name":"Multinazionali","where":"/slide_task_4"
		},
        {
			"name":"multinazionali","where":"/slide_task_4"
		},
        {
			"name":"Aiutare","where":"/slide_task_4"
		},
        {
			"name":"aiutare","where":"/slide_task_4"
		},
        {
			"name":"Quotidianità","where":"/slide_task_5"
		},
        {
			"name":"quotidiantà","where":"/slide_task_5"
		},
        {
			"name":"Pannelli Fotovoltaici","where":"/slide_task_3"
		},
        {
			"name":"pannelli fotovoltaici","where":"/slide_task_3"
		},
        {
			"name":"Pala Eolica","where":"/slide_task_3"
		},
        {
			"name":"pala eolica","where":"/slide_task_3"
		},
        {
			"name":"Biomassa","where":"/slide_task_3"
		},
        {
			"name":"biomassa","where":"/slide_task_3"
		},
        {
			"name":"impianto a biomassa","where":"/slide_task_3"
		},
        {
			"name":"Impianto a Biomassa","where":"/slide_task_3"
		},
        {
			"name":"Centrale Idroelettrica","where":"/slide_task_3"
		},
        {
			"name":"centrale idroelettrica","where":"/slide_task_3"
		},



	]
    resultdata = f.Row(
        scroll= 'auto'
    )
    resultcon = f.Container(
		bgcolor="#041955",
		padding=10,
		margin=10,
        border_radius=20,
		offset=f.transform.Offset(-2,0),
		animate_offset = f.animation.Animation(600,curve="easeIn"),
		content=f.Column([
            f.Text(f"Risultati ricerca:                                  ",size=15),
			resultdata
			])
		)
    def searchnow(e):
        mysearch = e.control.value
        result = []

# se ha scritto qualcosa esegui la funzione
        if not mysearch == "":
            resultcon.visible = True
            for item in data:
                if mysearch in item['name']:
                    resultcon.offset = f.transform.Offset(0,0)
                    result.append(item)
            page.update()

# se trova il risultato: 
        if result:
            resultdata.controls.clear()
            for x in result:
                resultdata.controls.append(
                        f.TextButton(text=f"{x['name']}",
                        on_click=lambda _: page.go(x['where']),
                        ),
					)
                
            page.update()
        else:
            resultcon.offset = f.transform.Offset(-2,0)
            resultdata.controls.clear()
            page.update()

    resultcon.visible = False
    txtsearch = f.TextField(label="Scrivi qui",
		on_change=searchnow
		)
    

#scrollo le categorie
    categories_card = f.Row(
        scroll= 'auto'
    )
    categories = ['Leggi','Gioca','Shop']

#creo la prima vignetta
    categories_card.controls.append(
            f.Container(
                bgcolor=BG,
                height=120,
                width=150,
                border_radius=20,
                padding=15,
                content=f.Column(
                    controls=[
                        f.Text(categories[0]),
                        f.FloatingActionButton(
                            icon = f.icons.ADD, on_click=lambda _: page.go('/create_task'),
                        ),
                    ]
                )

            )
        )

#creo la seconda vignetta
    categories_card.controls.append(
            f.Container(
                bgcolor=BG,
                height=120,
                width=150,
                border_radius=20,
                padding=15,
                content=f.Column(
                    controls=[
                        f.Text(categories[1]),
                        f.FloatingActionButton(
                            icon = f.icons.SEARCH, on_click=lambda _: page.go('/create_task2'),
                        ),
                    ]
                )

            )
        )

#creo la terza vignetta
    categories_card.controls.append(
            f.Container(
                bgcolor=BG,
                height=120,
                width=150,
                border_radius=20,
                padding=15,
                content=f.Column(
                    controls=[
                        f.Text(categories[2]),
                        f.FloatingActionButton(
                            icon = f.icons.MENU, on_click=lambda _: page.go('/create_task3'),
                        ),
                    ]
                )

            )
        )

#content pagina 1 con le slide
    create_task_view = f.Container(
        
        content = f.Column(
            height=800, 
            width = 360,
            scroll="always", 
            on_scroll_interval=0, 
            on_scroll=myscroll,
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Container(
                    content = f.Text("""\nIntroduzione:""", color='white',size=17),
                ),
                f.Container(
                    content = f.Text("""La storia dell'energia è un viaggio affascinante, dalle radici antiche alle moderne innovazioni. Partendo dal fuoco come prima fonte rinnovabile, abbiamo visto l'evoluzione attraverso mulini ad acqua, energia geotermica, idroelettrica, fino alle scoperte dell'energia solare ed eolica. La crisi del petrolio negli anni '70 ha accelerato l'interesse per fonti alternative, portando a una maggiore adozione di risorse rinnovabili.""", color='white'),
                ),
                f.Container(
                    content = f.Text("""\nEsamineremo l'impatto delle multinazionali, come compagnie petrolifere e aziende elettriche, criticate per pratiche non sostenibili. Tuttavia, emergono opportunità di cambiamento positivo. Infine, esploriamo come ogni individuo può contribuire alla sostenibilità energetica attraverso scelte consapevoli e supporto a iniziative eco-compatibili.""", color='white'),
                ),
                f.Container(
                    content = f.Text("""\nQuesto percorso storico ci guida a riflettere sul passato e plasmare un futuro più sostenibile per tutti.""", color='white'),
                ),
                f.Container(
                height = 50,
                width =360,
                content=f.FilledButton(text='Successiva'),
                on_click=lambda _: page.go('/create_task1'),
                
                ),
                f.Container(
                    content=f.Text("\n\n\n\n\n")
                )
            ]
            
            
        )
    )
    create_task_view1 = f.Container(
        
        content = f.Column(
            height=800, 
            width = 360,
            scroll="always", 
            on_scroll_interval=0, 
            on_scroll=myscroll,
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Container(
                        content = f.Text(f"""\n\nLA STORIA DELL'ENERGIA: """, color='white',size=17),
                ),
                f.Container(
                    content = f.Text("""L’energia sostenibile trae le sue radici dall’antichità e da allora si è sviluppata sempre più,anche grazie all’introduzione di nuove tecnologie.
                    \n•Il fuoco può essere considerato come una prima fonte energetica rinnovabile.
                    \n• In seguito, si è passati a strumenti costruiti dall’uomo, come mulini ad acqua e a vento. I mulini ad acqua erano sfruttati per la navigazione nei mari; mentre quelli a vento nelle attività agricole. 
                    \n• L’energia geotermica, invece, veniva sfruttata al fine di riscaldare le abitazioni e le terme.
                    \n• A partire dal diciannovesimo secolo venne utilizzata l’energia idroelettrica per generare elettricità. Garantendo un basso impatto ambientale e un’alta efficienza, essa sfrutta l’energia dell’acqua, la quale viene trasformata in elettricità per circa il 90%. Le centrali idroelettriche, in particolare, sfruttano la forza di gravità per accelerare l’acqua e liberarne tutta l’energia potenziale.
                    \n• Nel 1839 iniziò ad essere sfruttata l’energia solare, con la scoperta dell’effetto fotovoltaico. Essa è la fonte primaria di energia sulla terra, utilizzata anche da Albert Einstein come oggetto di studio. Da questa deriva la cella solare, che converte la radiazione del sole in energia elettrica. Un esempio classico di questa energia è dato dai pannelli fotovoltaici.
                    \n• Negli stessi anni si sviluppò anche l’utilizzo dell’energia eolica. Essa sfrutta la forza del vento per compiere un lavoro. Alcuni esempi di attività che sfruttano l’energia eolica sono: la macinazione del grano attraverso i mulini a vento, la pompatura dell’acqua dai pozzi e la navigazione a vela. Tuttavia, l’esempio più comune è dato dalle pale eoliche. 
                    \n• Intorno al 1970, la crisi del petrolio contribuì ad un maggiore sfruttamento delle risorse rinnovabili e aumentò l’interesse per le fonti di energia alternative.              
                    \n• Successivamente, a partire dagli anni ‘90, grazie a tecnologie sempre più efficienti, sono state affinate maggiormente queste tecniche al fine di renderle più funzionali ed accessibili.
                    \n \nAnche oggi si continua a ricercare modi per migliorare la sostenibilità energetica, andando verso la realizzazione di un futuro con un minore impatto ambientale. 
                                    """, color='white'),
                    
                ),
                f.Container(
                height = 50,
                width =360,
                content=f.FilledButton(text='Successiva'),
                on_click=lambda _: page.go('/slide_task_2'),
                
                ),
                f.Container(
                    height = 50,
                    width =360,
                    content=f.FilledButton(text='Precendente'),
                    on_click=lambda _: page.go('/create_task'),
                    
                    ),
                f.Container(
                    content=f.Text("\n\n\n\n\n")
                )
            ]
            
            
        )
    )
    slide_task_view_2 = f.Container(
            
            content = f.Column(
                height=800, 
                width = 360,
                scroll="always", 
                on_scroll_interval=0, 
                on_scroll=myscroll,
                controls = [
                    f.Container(
                    height=30,
                    width =60,
                    content=f.FilledButton(text='x'),
                    on_click=lambda _: page.go('/'),
                    ),
                    f.Container(
                        content = f.Text(f"""\n\nTIPI DI ENERGIA: """, color='white',size=17),
                        ),
                    f.Container(
                        content = f.Text(f"""\nI tipi di energia principali sono sei:
                        \n• energia meccanica\n• energia chimica\n• energia elettromagnetica\n• energia gravitazionale\n• energia termica\n• energia nucleare
                        """, color='white'),
                        ),
                        f.Container(
                        content = f.Text(f"""\nL'ENERGIA MECCANICA: """, color='white',size=17),
                        ),
                        f.Container(
                        content = f.Text(f""" \nL’energia meccanica è data dalla somma tra energia cinetica e potenziale di uno stesso sistema. In fisica ciò è tradotto dalla formula E = K + U e si misura in Joule (J).
L’energia cinetica deriva dal movimento, quindi se l’oggetto si trova inizialmente fermo, l’energia meccanica sarà data solo dall’energia potenziale: E = U. 
L’energia potenziale dipende dalla posizione dell’oggetto, quindi se esso si trova ad un’altezza zero, l’energia meccanica sarà data solamente dall’energia cinetica: E = K.
Quando due sistemi scambiano tra loro energia meccanica, tale energia scambiata viene definita lavoro. Mentre l’energia meccanica può essere sia posseduta da un sistema, sia scambiata fra vari sistemi; il lavoro è solo la parte di energia meccanica che viene scambiata.  """, color='white'),
                        ),
                        f.Container(
                        content = f.Text(f""" \n\nL'ENERGIA CHIMICA: """, color='white',size=17),
                        ),
                        f.Container(
                        content = f.Text(f""" \nL’energia chimica è una forma di energia interna immagazzinata nei legami chimici. Essa varia durante le reazioni chimiche, in base al calore che viene assorbito o prodotto. Nel primo caso si assiste ad un aumento dell’energia chimica, nel secondo a una riduzione. 
L’energia di legame tende a zero quando la distanza tra due atomi tende all’infinito e diminuisce quando tali atomi si avvicinano. 
Quando essa raggiunge il minimo energetico, che corrisponde alla condizione di massima stabilità, si forma il legame chimico. 
L’energia chimica può essere definita anche come la capacità di alcune sostanze di legarsi con altre sviluppando energia sotto forma di luce, calore ed elettricità. """, color='white'),
                        ),
                        f.Container(
                        content = f.Text(f""" \n\nL'ENERGIA ELETTROMAGNETICA: """, color='white',size=17),
                        ),
                        f.Container(
                        content = f.Text(f""" \nL’energia elettromagnetica è l’energia immagazzinata in una data regione di spazio del campo elettromagnetico. Essa è costituita dalla somma delle energie associate al campo elettrico e a quello magnetico. 
Il campo elettromagnetico è generato localmente da qualunque distribuzione di carica elettrica e corrente elettrica variabili nel tempo.  """, color='white'),
                        ),
                        
                        f.Container(
                        content = f.Text(f"""\n\nL'ENERGIA GRAVITAZIONALE: """, color='white',size=17),
                        ),
                        f.Container(
                        content = f.Text(f"""\nL’energia gravitazionale è l’energia potenziale relativa alla forza di attrazione gravitazionale fra masse. 
La forza di attrazione gravitazionale (o interazione gravitazionale) è una conseguenza della curvatura dello spazio-tempo creata dalla presenza di corpi dotati di massa o energia. 
In fisica, la formula dell’energia potenziale gravitazionale è: U=mgh. Infatti, essa è data dal prodotto tra la massa di un corpo,  l’altezza in cui si trova quel corpo e la costante di gravitazione universale (g = 9,81 N/Kg).
L’energia gravitazionale può anche essere definita come l’energia che viene immagazzinata da un corpo per poter svolgere un lavoro ad una certa altezza, alla quale si trova il corpo. In relazione al lavoro è data dalla formula:  ΔU = Q + L. Dove la variazione di energia potenziale interna è data dalla somma tra il calore e il lavoro. """, color='white'),
                        ),
                        f.Container(
                        content = f.Text(f"""\n\nL'ENERGIA TERMICA: """, color='white',size=17),
                        ),
                        f.Container(
                        content = f.Text(f"""\nL’energia termica è la forma di energia posseduta da qualsiasi corpo che abbia una temperatura superiore allo zero assoluto. 
In accordo con il terzo principio della termodinamica, ciò significa che essa è presente in ogni corpo, perché non è possibile abbassare la temperatura di un qualsiasi sistema allo zero assoluto mediante un numero finito di trasformazioni. 
Essa è una grandezza estensiva, cioè è proporzionale alla temperatura e all’estensione del corpo. 
Il calore è prodotto dal movimento oscillatorio di atomi e molecole attorno a un corpo. Quindi l’energia termica è data dalla somma dell’energia cinetica degli atomi che costituiscono un oggetto e dipende dalla massa di tale oggetto. 
""", color='white'),
                        ),
                        f.Container(
                        content = f.Text(f"""\nL'ENERGIA NUCLEARE: """, color='white',size=17),
                        ),
                        f.Container(
                        content = f.Text(f"""\nL’energia nucleare è l’energia liberata dalle reazioni nucleari e dal decadimento radioattivo sotto forma di energia cinetica e elettromagnetica. Comunemente ci si riferisce ad essa come l’energia liberata in modo controllato nelle centrali nucleari per la produzione di energia elettrica. 
Durante questa, piccole quantità di materia vengono trasformate in energia grazie all’equivalenza fra massa ed energia descritta da Albert Einstein E=mc2.
Dalla divisione di atomi pesanti si ha la fissione nucleare, mentre dall’unione di due atomi leggeri si ha la fusione nucleare.
""", color='white'),
                        ),
                        
                    f.Container(
                    height = 50,
                    width =360,
                    content=f.FilledButton(text='Successiva'),
                    on_click=lambda _: page.go('/slide_task_3'),
                    
                    ),
                    f.Container(
                    height = 50,
                    width =360,
                    content=f.FilledButton(text='Precendente'),
                    on_click=lambda _: page.go('/create_task1'),
                    
                    ),
                    f.Container(
                        content=f.Text("\n\n\n\n\n")
                    )
                ]
                
                
            )
        )
    slide_task_view_3 = f.Container(
            
            content = f.Column(
                height=800, 
                width = 360,
                scroll="always", 
                on_scroll_interval=0, 
                on_scroll=myscroll,
                controls = [
                    f.Container(
                    height=30,
                    width =60,
                    content=f.FilledButton(text='x'),
                    on_click=lambda _: page.go('/'),
                    ),
                    f.Container(
                        content = f.Text(f"""\nCome sono fatti i pannelli fotovoltaici? """, color='white',size=17),
                    ),
                    f.Container(
                        content = f.Text(f"""\nUn pannello fotovoltaico è composto da unità dette celle, di solito fatte di un materiale semiconduttore come il silicio con l’aggiunta di atomi di altri elementi come boro e fosforo.\nLe celle sono poi posizionate una accanto all’altra su una superficie piana e collegate tra loro.
                                        \nPer proteggere questo sistema si monta uno speciale vetro di copertura, appositamente trattato per ottenere la massima resa di energia.\nI pannelli sfruttano l’irraggiamento del sole e non il calore dell’aria: per questo motivo non c’è bisogno di un clima particolarmente caldo, anzi l’efficienza è al massimo se la temperatura delle celle resta al di sotto dei 25°C.\nNormalmente un pannello solare ha una vita piuttosto lunga, circa 25 o 30 anni. 
                                        \nLa conversione dei raggi solari in energia elettrica avviene all’interno delle celle fotovoltaiche: i fotoni della luce solare che colpiscono il silicio- a cui sono stati aggiunti gli altri elementi - fanno liberare degli elettroni, producendo così una corrente elettrica continua. Dato che nelle case viene utilizzata la corrente alternata, bisogna installare un dispositivo chiamato inverter, che trasforma appunto la corrente da continua ad alternata.
                                        """, color='white'),
                    ),
                    f.Container(
                        content = f.Text(f"""\nCome è  fatta una pala eolica? """, color='white',size=17),
                    ),
                    f.Container(
                        content = f.Text(f"""\nLa pala eolica
(o aerogeneratore, o turbina eolica) è un piccolo capolavoro di ingegneria, dall’aspetto solo in apparenza elementare. La tipologia più diffusa è la classica pala eolica ad asse orizzontale, composta da torre, navicella e rotore, alla cui estremità sono poste solitamente 3 pale (anche chiamate lame). Meno diffuse sono le pale eoliche ad asse verticale, poco utilizzate per problemi di resistenza all’aria.processo di funzionamento di una pala eolica è apparentemente semplice: il rotore - attivato dal vento - trasmette la sua rotazione a un albero veloce, che a sua volta alimenta il generatore elettrico. I cosiddetti sistemi di imbardata permettono l'orientamento della navicella a seconda della direzione del vento. Il rotore entra in funzione solo quando il vento raggiunge una velocità superiore ai 10 Km/h, mentre oltre i 90 Km/h l'aerogeneratore si arresta per motivi di sicurezza. """, color='white'),
                    ),
                    f.Container(
                        content = f.Text(f"""Nel dettaglio, dal rotore l'energia cinetica del vento viene quindi convertita in energia meccanica. Un moltiplicatore di giri trasforma la rotazione lenta delle pale (tra i 18 e i 25 giri al minuto) in una rotazione più veloce (fino a 1800 giri al minuto) in grado di far funzionare il generatore di elettricità. Il generatore elettrico converte l’energia meccanica ricevuta in energia elettrica. Un trasformatore provvederà a trasferire l’energia elettrica da un circuito a un altro (la rete elettrica in questo caso), modificandone le caratteristiche.""", color='white'),
                    ),
                    f.Container(
                        content = f.Text(f"""Sulla navicella della pala eolica sono presenti vari sistemi di controllo, per monitorare in continuazione i parametri di funzionamento della pala eolica e consentire di produrre energia rinnovabile in totale sicurezza, massimizzando l’efficienza all’interno di un parco eolico. """, color='white'),
                    ),

                    f.Container(
                        content = f.Text(f"""\nChe cos'è un impianto a Biomassa? """, color='white',size=17),
                    ),
                    f.Container(
                        content = f.Text(f"""\nUn impianto di biomassa funziona attraverso il processo di combustione controllata di materiali organici per generare calore o energia. Ecco i passaggi chiave:
                                        \n• *Alimentazione della biomassa:* Materiali organici come legno, residui agricoli o rifiuti solidi vengono alimentati nell'impianto.
                                        \n• *Combustione:* La biomassa viene bruciata in una camera di combustione controllata, producendo calore. Questo può avvenire attraverso la combustione diretta o la gassificazione, a seconda del tipo di impianto.
                                        \n• *Generazione di calore:* Il calore prodotto viene utilizzato per generare vapore o acqua calda.
                                        \n• *Generazione di energia:* Il vapore o l'acqua calda possono essere utilizzati per alimentare una turbina collegata a un generatore elettrico, producendo così energia elettrica.
                                        \n• *Trattamento dei residui:* Il processo può generare ceneri e altri sottoprodotti. Alcuni impianti gestiscono questi residui in modo sostenibile, ad esempio utilizzandoli come fertilizzanti o per altri scopi.
                                        \n\nL'uso di biomassa può essere considerato più sostenibile rispetto a fonti di energia non rinnovabile, poiché il carbonio rilasciato durante la combustione è in gran parte equivalente a quello assorbito dalle piante durante la loro crescita, creando un ciclo di carbonio chiuso.""", color='white'),
                    ),
                    f.Container(
                        content = f.Text(f"""\nCome funziona una Centrale Idroelettrica? """, color='white',size=17),
                    ),
                    f.Container(
                        content = f.Text(f"""\nLa centrale idroelettrica trasforma l'energia idraulica di un corso d'acqua, naturale o artificiale, in energia elettrica rinnovabile.
                                        \nLa centrale idroelettrica può essere di tre tipi: ad acqua fluente, a bacino o ad accumulazione. 
                                        \nCome funziona?
                                        \nIn linea generale, lo schema di una centrale comprende un’opera di sbarramento - una diga o una traversa - che intercetta il corso d'acqua, creando un invaso che può essere un serbatoio o un bacino idroelettrico.
                                        \nAttraverso opere di adduzione, canali e gallerie di derivazione, l'acqua viene convogliata da condotte forzate dalla diga verso le turbine idrauliche, che ruotando generano energia meccanica, convertita poi in energia elettrica dal generatore elettrico rotante.
                                        \nL'acqua mette in azione le turbine, generando energia meccanica, e ne esce finendo in un canale di scarico, attraverso il quale viene restituita al corso d’acqua.
                                        \nDirettamente collegato alla turbina è montato il generatore elettrico rotante (alternatore), che trasforma in energia elettrica l'energia meccanica ricevuta dalla turbina.
                                        \nL’elettricità così ottenuta deve essere trasformata per poter essere trasmessa a grande distanza: prima di essere convogliata nelle linee di trasmissione, l'energia elettrica passa quindi attraverso il trasformatore, che abbassa l'intensità della corrente prodotta dal generatore elettrico rotante, elevandone però la tensione.
                                        \nUna volta giunta sul luogo d’impiego, prima di essere utilizzata, l'energia passa di nuovo in un trasformatore, che questa volta alza l'intensità di corrente ed abbassa la tensione, così da renderla adatta agli utilizzi industriali, commerciali o domestici.""", color='white'),
                    ),
                    f.Container(
                    height = 50,
                    width =360,
                    content=f.FilledButton(text='Successiva'),
                    on_click=lambda _: page.go('/slide_task_4'),
                    
                    ),
                    f.Container(
                    height = 50,
                    width =360,
                    content=f.FilledButton(text='Precendente'),
                    on_click=lambda _: page.go('/slide_task_2'),
                    
                    ),
                    f.Container(
                        content=f.Text("\n\n\n\n\n")
                    )
                ]
                
                
            )
        )
    slide_task_view_4 = f.Container(
            
            content = f.Column(
                height=800, 
                width = 360,
                scroll="always", 
                on_scroll_interval=0, 
                on_scroll=myscroll,
                controls = [
                    f.Container(
                    height=30,
                    width =60,
                    content=f.FilledButton(text='x'),
                    on_click=lambda _: page.go('/'),
                    ),
                    f.Container(
                        f.Text("\n\nIMPATTO AMBIENTALE DELLE MULTINAZIONALI:",size=17, color='white'),
                    ),
                    f.Container(
                        content = f.Text(f"""\nLe multinazionali spesso contribuiscono alla mancanza di sostenibilità energetica attraverso varie pratiche. 
                        \nMolte di queste grandi aziende prioritizzano i profitti a breve termine sopra gli sforzi per adottare fonti energetiche sostenibili. 
                        \nSpesso dipendono pesantemente da combustibili fossili, ignorando o sotto investendo nelle energie rinnovabili e nelle tecnologie eco-compatibili. \nInoltre, alcune multinazionali possono esercitare una pressione politica per mantenere status quo favorevoli ai combustibili fossili, influenzando le politiche pubbliche a scapito di iniziative sostenibili. 
                        \nIl mancato impegno delle multinazionali nel passare a fonti energetiche più pulite e sostenibili contribuisce significativamente all'accelerazione dei cambiamenti climatici e alla scarsità di risorse energetiche rinnovabili, compromettendo così la sostenibilità ambientale a lungo termine.
                        """, color='white'),
                    ),
                    f.Container(
                        f.Text("\nALCUNI ESEMPI DI MULTINAZIONALE:",size=17, color='white'),
                    ),
                    f.Container(
                        content= f.Text("""\nDiverse multinazionali hanno ricevuto critiche per il loro impatto sulla sostenibilità energetica.
                        \nAd esempio, compagnie petrolifere come ExxonMobil, Chevron e BP sono state oggetto di critiche per il loro ruolo nel mantenere una dipendenza globale dai combustibili fossili e per il loro coinvolgimento in incidenti ambientali, come le fuoriuscite di petrolio che hanno danneggiato gli ecosistemi marini.
                        \nNel settore dell'industria elettrica, aziende come Duke Energy e E.ON sono state criticate per il loro ritardo nell'abbandonare le centrali elettriche a carbone, nonostante il crescente appello per una transizione verso fonti energetiche più pulite come l'energia solare o eolica.
                        \nAnche nell'ambito della produzione di beni di consumo, ci sono multinazionali come Coca-Cola, accusate di non fare abbastanza per ridurre l'impatto ambientale delle loro operazioni, come il consumo eccessivo di plastica non riciclabile per le bottiglie.
                        \nQuesti sono solo alcuni esempi di aziende multinazionali criticate per il loro impatto negativo sulla sostenibilità energetica, poiché spesso mantengono pratiche che favoriscono i combustibili fossili o non investono abbastanza in alternative energetiche più sostenibili.
                                    """, color='white'),
                        ),
                    f.Container(
                        f.Text("\nCOME AIUTARE NEL NOSTRO PICCOLO?",size=17, color='white'),
                    ),
                    f.Container(
                        content= f.Text("""\nCi sono diversi modi in cui le persone possono contribuire a influenzare il comportamento delle multinazionali e promuovere la sostenibilità nelle loro azioni quotidiane:
                        \n• Scelte consapevoli di acquisto: \nPreferire prodotti e marchi che dimostrano un impegno verso la sostenibilità ambientale può influenzare le multinazionali. Scegliere prodotti con certificazioni ambientali, provenienti da fonti sostenibili o con imballaggi riciclabili può incoraggiare le aziende a migliorare le loro pratiche.
                        \n• Supportare le iniziative sostenibili: \nSostenere e partecipare a progetti o movimenti che promuovono la sostenibilità, come petizioni per energie rinnovabili, iniziative locali per la riduzione della plastica o attività di sensibilizzazione sul cambiamento climatico, può esercitare pressione sulle multinazionali affinché adottino politiche più eco-compatibili.
                        \n• Coinvolgimento politico: \nPartecipare attivamente alle elezioni e sostenere politici che promuovono leggi e regolamenti a favore dell'ambiente e delle energie rinnovabili può influenzare l'indirizzo delle politiche governative e quindi l'atteggiamento delle multinazionali.
                        \n• Condivisione di informazioni: \nEducare gli altri sulle pratiche non sostenibili delle multinazionali attraverso social media, articoli, o conversazioni può sensibilizzare un pubblico più ampio e mettere pressione sulle aziende affinché migliorino le loro politiche.
                        \n• Investimenti responsabili: \nInvestire in aziende e fondi che promuovono la sostenibilità ambientale e sociale può contribuire a spingere le multinazionali a prendere in considerazione queste tematiche nel loro modello di business.
                        \n\nCombattere le multinazionali per favorire la sostenibilità richiede un impegno continuo da parte dei consumatori, degli attivisti e dei cittadini consapevoli, incoraggiando cambiamenti positivi nel comportamento delle aziende verso un futuro più sostenibile.
                        """),
                    ),
                                        
                    
                    f.Container(
                    height = 50,
                    width =360,
                    content=f.FilledButton(text='Successiva'),
                    on_click=lambda _: page.go('/slide_task_5'),
                    
                    ),
                    f.Container(
                    height = 50,
                    width =360,
                    content=f.FilledButton(text='Precendente'),
                    on_click=lambda _: page.go('/slide_task_3'),
                    
                    ),
                    f.Container(
                        content=f.Text("\n\n\n\n\n")
                    )
                
                ]
                
                
            )
        )
    slide_task_view_5 = f.Container(
                
                content = f.Column(
                    height=800, 
                    width = 360,
                    scroll="always", 
                    on_scroll_interval=0, 
                    on_scroll=myscroll,
                    controls = [
                        f.Container(
                        height=30,
                        width =60,
                        content=f.FilledButton(text='x'),
                        on_click=lambda _: page.go('/'),
                        ),
                        f.Container(
                            content = f.Text(f""" Quotidianità: """, color='white',size =17),
                        ),
                        f.Container(
                            content = f.Text(f"""\nChiunque può dare il suo contributo alla sostenibilità energetica ogni giorno, tramite piccole azioni , che potrebbero anche richiedere sacrifici, ma che anche possono dare un grande aiuto. 
                            \nOgnuno di noi in media consuma una quantità di energia pari a 80 kWh, i quali vengono utilizzati per permetterci i lussi quotidiani ai quali siamo abituati, come per esempio il riscaldamento o gli spostamenti.  Ciò che dovremmo cercare di fare è di ridurre gli eccessivi sprechi di energia o sfruttare meglio l’energia che usiamo.
                            \nPer esempio parlando dei riscaldamenti, dovremmo cercare di sottrarci a molte cattive abitudini alle quali siamo abituati, per evitare uno spreco di energia, tramite piccoli gesti, come:
                            \n\n• Riscaldare poco o per niente i locali poco utilizzati
                            \n•Non tenere aperte le finestre durante il riscaldamento
                            \n•Tenere una temperatura che vada dai 20°C ai 16°C (anche un solo grado di differenza può far risparmiare il 7% di energia)
                            \n•Eseguire vari controlli agli impianti di riscaldamento e se possibile fare il modo che questi sfruttino fonti di energia rinnovabili (come biomasse)
                            \n\nUn altra causa principale dello spreco energetico sono gli spostamenti. Purtroppo la maggior parte di noi sceglie di utilizzare la macchina in tutti i propri spostamenti, non sapendo che anche solo percorrere 1 km con una vettura a gasolio o benzina richiede 1 kWh di energia. Al contrario ci sono molte altre alternative molto più sostenibili all’auto, come per esempio una bicicletta o un monopattino elettrico per gli spostamenti vicini. Per i viaggi più lunghi si possono utilizzare treni o aerei. In caso si volesse però usare l’auto, si hanno alcune accortezze che è possibile applicare alla propria vettura, come utilizzare una macchina ibrida o elettrica, cercare di tenere la velocità costante e utilizzare pneumatici che diminuiscano l’emissione di CO2.
                            \nIl maggiore spreco di energia proviene però dall’energia elettrica, alla quale abbiamo tutti accesso nelle nostre case. Questa viene sfruttata soprattutto per il funzionamento di elettrodomestici, come frigoriferi o lavastoviglie, ma fortunatamente si hanno moltissimi dispositivi a basso consumo. Questi sono riconoscibili grazie a un’ etichetta che li classifica in base al livello di consumo con un livello che va dalla A+(poco consumo) alla G(alto consumo). Gli A permettono di sfruttare un terzo dell’energia usata dai G, permettendo un risparmio circa del 74%.
Inoltre per tappare l’eccessivo consumo di energia elettrica bisognerebbe adottare un comportamento responsabile tramite determinate azioni, ovvero:
                            \n\n• Ricordarsi di spegnere la luce
                            \n• Usare meno lampadine possibili e se possibile usare quelle a LED.
                            \n• regolare i termostati di frigoriferi con temperature non troppo elevate
                            \n• Usare la lavastoviglie quando piena
                            \n\nCiò che si può intuire è che il problema vero e proprio sono le nostre abitudini totalmente scorrette alle quali ormai siamo tutti abituati. Sarebbe opportuno regolarsi sulla base di questi consigli in modo da aiutare noi stessi e ciò che ci sta intorno.
                                        """, color='white'),
                        ),
                        
                        f.Container(
                        height = 50,
                        width =360,
                        content=f.FilledButton(text='Precendente'),
                        on_click=lambda _: page.go('/slide_task_4'),
                        
                        ),
                        f.Container(
                            content=f.Text("\n\n\n\n\n")
                        )
                    ]
                    
                    
                )
            )
#content pagina 2 con il quiz
    create_task_view2 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('Inizia',size=25)
                )]),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.FilledButton(text='Clicca qui per iniziare',on_click=lambda _: page.go('/quiz'),)
                )]),
            ]
            
            
        )
    )
    quiz = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('che tipo di energia è\n la gravitazionale?',size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='cinetica',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text='potenziale',on_click=lambda _: page.go('/quiz1'),width=150 )
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='meccanica',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text='termica',on_click=lambda _: page.go('/error'),width=150 )
                    ]),

            ]
            
            
        )
    )
    quiz1 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('Qual è l’energia utilizzata \nper generare elettricità?',size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='solare',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text='nucleare',on_click=lambda _: page.go('/error'), width=150)
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='idroelettrica',on_click=lambda _: page.go('/quiz2'),width=150 ),
                        f.FilledButton(text='elettrica',on_click=lambda _: page.go('/error'), width=150)
                    ]),
            ]
            
            
        )
    )
    quiz2 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('Da quale delle nostre \nnecessità quotidiane \nproviene il maggiore \nspreco di energia?',size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Spostamenti',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text='Energia elettrica',on_click=lambda _: page.go('/quiz3'), width=150)
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Riscaldamento',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text='Spreco acqua calda',on_click=lambda _: page.go('/error'), width=150)
                    ]),
            ]
            
            
        )
    )
    quiz3 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('Per quanto riguarda \ngli spostamenti, qual’è \nil mezzo meno sostenibile?',size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Automobile',on_click=lambda _: page.go('/quiz4'),width=150 ),
                        f.FilledButton(text='Aereo',on_click=lambda _: page.go('/error'), width=150)
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Bicicletta',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text='Treno',on_click=lambda _: page.go('/error'), width=150)
                    ]),
                
                
                
                
            ]
            
            )
            
        )
    quiz4 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('Quali sono alcune azioni \nche le multinazionali \npossono adottare \nper promuovere \nla sostenibilità ambientale?',size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text=' Investire in combustibili fossili',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text="Ridurre l'uso di imballaggi monouso non riciclabili ",on_click=lambda _: page.go('/quiz5'), width=150)
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Ignorare le energie rinnovabili',on_click=lambda _: page.go('/error'),width=150 ),
                        f.FilledButton(text='Sostenere progetti di deforestazione',on_click=lambda _: page.go('/error'), width=151)
                    ]),
            ]
            
            
        )
    )
    quiz5 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('Quali sono alcuni modi \nin cui i consumatori \npossono influenzare \nle multinazionali verso \npratiche più sostenibili?',size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Acquistare solo prodotti con imballaggi in plastica non riciclabile',on_click=lambda _: page.go('/error'),width=150, height=120,),
                        f.FilledButton(text="Sostenere l'uso eccessivo di risorse naturali",on_click=lambda _: page.go('/error'), width=150,height=120,)
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Ignorare le pratiche ambientali durante gli acquisti',on_click=lambda _: page.go('/error'),width=145,height=120, ),
                        f.FilledButton(text='Preferire marchi impegnati nella sostenibilità ambientale.',on_click=lambda _: page.go('/quiz6'), width=155,height=120,)
                    ]),
            ]
            
            
        )
    )
    quiz6 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('Come funziona \nuna pala eolica?',size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text=" Il rotore trasmette la rotazione a un albero lento",on_click=lambda _: page.go('/quiz7'),width=150,height=120 ),
                        f.FilledButton(text="Il generatore converte energia termica in elettricità",on_click=lambda _: page.go('/error'),width=150,height=120 )
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text="Il sistema di imbardata non influenza l'orientamento della navicella",on_click=lambda _: page.go('/error'),width=150,height=120 ),
                        f.FilledButton(text="Il rotore si attiva solo a velocità inferiori ai 10 Km/h",on_click=lambda _: page.go('/error'),width=150,height=120)
                    ]),
            ]
            
            
        )
    )
    quiz7 = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text("Com'è fatto un pannello \nfotovoltaico?",size=25)
                )]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text='Le celle sono fatte di alluminio',on_click=lambda _: page.go('/error'),width=150,height=120),
                        f.FilledButton(text='Le celle sono fatte di vetro',on_click=lambda _: page.go('/error'),width=150,height=120)
                    ]),
                f.Row(alignment='spaceBetween',
                    controls = [
                        f.FilledButton(text="Le celle sono fatte di silicio con l'aggiunta di boro e fosforo",on_click=lambda _: page.go('/win'),width=150,height=120 ),
                        f.FilledButton(text=' Le celle sono fatte di plastica riciclata',on_click=lambda _: page.go('/error'),width=150,height=120)
                    ]),
            ]
            
            
        )
    )
    
    error = f.Container(
        
        content = f.Column(
            controls = [
                f.Container(
                height=30,
                width =60,
                content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('HAI SBAGLIATO',size=25)
                )]),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.FilledButton(text='Riprova',on_click=lambda _: page.go('/create_task2'), )
                )]),
            ]
            
            
        )
    )
    win = f.Container(
        
        content = f.Column(
            controls = [
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.Text('HAI VINTO',size=30)
                )]),
                f.Row(alignment='center',
                    controls = [
                        f.Container(
                            content = f.FilledButton(text='Clicca qui',on_click=lambda _: page.go('/'),)
                        )
                    ]),
            ]
            
            
        )
    )
    

#content pagina 3 con lo shop
    create_task_view3 = f.Container(
        content = f.Column(
            height=800, 
            width = 360,
            scroll="always", 
            on_scroll_interval=0, 
            on_scroll=myscroll,
            controls = [
                f.Container(
                    height=30,
                    width =60,
                    content=f.FilledButton(text='x'),
                on_click=lambda _: page.go('/'),
                ),
                
                f.Container(
                    f.Container(
                    padding=10,
                content=
                        f.Text('\nShop Ecosostenibile:',size=20)
                        )
                ),
                f.Container(
                    bgcolor='#041955',
                    border_radius=10,
                    padding=10,
                    width=300,
                    content = f.Column(
                    controls = [
                        
                        f.Container(
                    content = f.Text('  Pneumatici fuel economy:',size=17,color='white')
                    ),
                f.Row(alignment='center',
                    controls = [
                        f.Container(
                    content = f.FloatingActionButton(
                        icon = f.icons.PLAY_CIRCLE_FILL_OUTLINED,
                        on_click=lambda _: page.launch_url('https://www.gommeplanet.it/pneumatici-auto-e-furgoni/gomme-4-stagioni-auto/gomma-michelin-in-offerta-modello-crossclimate-2-195-65-15-95-v-3528702438138?gad_source=1&gclid=Cj0KCQiA4NWrBhD-ARIsAFCKwWtsbZBvfZsGKGssxeoUBdZV5y2Y936vSlWTgouEFu9hsYNwhgQTMOYaAihLEALw_wcB'),
                    ),
                ),
                    ]
                    )
                
                    ]
                    )
                ),
                f.Container(
                    bgcolor='#041955',
                    border_radius=10,
                    padding=10,
                    width=300,
                    content = f.Column(
                    controls = [
                f.Container(
                    content = f.Text('  Lampadine a led:',size=17,color='white')
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.FloatingActionButton(
                        icon=f.icons.SEARCH,
                        
                        on_click=lambda _: page.launch_url('https://amzn.eu/d/3NsfgJn'),
                    ),
                    
                ),]),
                ]
                    )
                ),
                f.Container(
                    bgcolor='#041955',
                    border_radius=10,
                    padding=10,
                    width=300,
                    content = f.Column(
                    controls = [
                f.Container(
                    content = f.Text('  Aspriapolveri automatici:',size=17,color='white')
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.FloatingActionButton(
                        icon=f.icons.PLAY_CIRCLE_FILL_OUTLINED,
                        
                        on_click=lambda _: page.launch_url('https://amzn.eu/d/5kFh2vi'),
                    ),
                    
                ),
                    ]),
                ]
                    )
                ),
                f.Container(
                    bgcolor='#041955',
                    border_radius=10,
                    padding=10,
                    width=300,
                    content = f.Column(
                    controls = [
                f.Container(
                    content = f.Text('  Valvole termostatiche ',size=17,color='white')
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.FloatingActionButton(
                        icon=f.icons.SEARCH,
                        
                        on_click=lambda _: page.launch_url('https://amzn.eu/d/cTVI5QL'),
                    ),
                    
                ),]),
                ]
                    )
                ),
                f.Container(
                    bgcolor='#041955',
                    border_radius=10,
                    width=300,
                    padding=10,
                    content = f.Column(
                    controls = [
                f.Container(
                    content = f.Text('  Elettrodomestici A+',size=17,color='white')
                ),
                f.Row(alignment='center',
                    controls = [
                f.Container(
                    content = f.FloatingActionButton(
                        icon=f.icons.PLAY_CIRCLE_FILL_OUTLINED,
                        on_click=lambda _: page.launch_url('https://amzn.eu/d/gY4ez92'),
                    ),
                    
                ),]),
                ]
                    )
                ),
                        
                f.Container(
                            content=f.Text("\n\n\n\n\n")
                        )
                
            ]
            
            
        )

    )
    
#content pagina 3 con il search
    search_box = f.Container(
        content =f.Column(
        controls =[
            f.Container(
            height = 20,
            width =50,
            content=f.Text('<-----',size =10),
            on_click=lambda _: page.go('/'),
            ),
            f.Column([
                f.Text("Cerca",size = 20,weight="bold"),
                txtsearch,
                resultcon
                ]),
            f.Container(
                    padding=f.padding.only(
                        top=10,
                        bottom=20,
                    ),
                    content = categories_card
                ),
        ]
        )
        
    )
    

#content della home
    home_page_contents = f.Container(
        content=f.Column(
            controls=[
                f.Row(alignment='spaceBetween',
                    controls=[
                        f.Container(
                            content=f.Icon(
                                f.icons.MENU)),

                        f.Container(
                            f.Icon(f.icons.SEARCH),
                            on_click =lambda _: page.go('/search'),
                        )
                            

                    ]
                ),
                f.Text(value="Ciao"),
                f.Text(value="CATEGORIES"),
                f.Container(
                    padding=f.padding.only(
                        top=10,
                        bottom=20,
                    ),
                    content = categories_card
                ),

                    f.Text(value = " Credits:  Gianmarco Lugaresi"),
                
                
            ],
        ),
    )

#se voglio creare una colonna di cose nella pagina principale
    tasks = f.Column(
    )

#funziamento e granezza pagine
    page_2 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius= 20,
                padding=f.padding.only(
                    top=45,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        home_page_contents
                    ]
                )
            )
        ]
    )
    slide = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right= 30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        create_task_view
                    ]
                )
            )
        ]
    )
    slide1 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right= 30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        create_task_view1
                    ]
                )
            )
        ]
    )
    
    slide2 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right= 30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        slide_task_view_2
                    ]
                )
            )
        ]
    )
    slide3 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right= 30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        slide_task_view_3
                    ]
                )
            )
        ]
    )
    slide4 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right= 30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        slide_task_view_4
                    ]
                )
            )
        ]
    )
    slide5 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right= 30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        slide_task_view_5
                    ]
                )
            )
        ]
    )
    game = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        create_task_view2
                    ]
                )
            )
        ]
    )
    quiz = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz
                    ]
                )
            )
        ]
    )
    quiz1 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz1
                    ]
                )
            )
        ]
    )
    quiz2 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz2
                    ]
                )
            )
        ]
    )
    quiz3 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz3
                    ]
                )
            )
        ]
    )
    quiz4 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz4
                    ]
                )
            )
        ]
    )
    quiz5 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz5
                    ]
                )
            )
        ]
    )
    quiz6 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz6
                    ]
                )
            )
        ]
    )
    quiz7 = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        quiz7
                    ]
                )
            )
        ]
    )
    
    error = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        error
                    ]
                )
            )
        ]
    )
    win = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        win
                    ]
                )
            )
        ]
    )
    shop = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        create_task_view3
                    ]
                )
            )
        ]
    )
    search = f.Row(
        controls=[
            f.Container(
                width=360,
                height=850,
                bgcolor=FG,
                border_radius=20,
                padding=f.padding.only(
                    top=55,
                    left=20,
                    right=30,
                    bottom=5
                ),
                content=f.Column(
                    controls=[
                        search_box
                    ]
                )
            )
        ]
    )
#sfondo home
    container = f.Container(
        width=360,
        height=800,
        border_radius= 20,
        bgcolor=BG,
        
        content=f.Stack(
            controls=[
                page_2,
            ]  
        )
    )

#sfondo slide
    container_slide = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                slide,
            ]  
        )
    )
    container_slide1 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                slide1,
            ]  
        )
    )
    
    container_slide2 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                slide2,
            ]  
        )
    )
    container_slide3 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                slide3,
            ]  
        )
    )
    container_slide4 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                slide4,
            ]  
        )
    )
    container_slide5 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                slide5,
            ]  
        )
    )
#sfondo quiz
    container_game = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                game,
            ]  
        )
    )
    quiz = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz,
            ]  
        )
    )
    quiz1 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz1,
            ]  
        )
    )
    quiz2 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz2,
            ]  
        )
    )
    quiz3 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz3,
            ]  
        )
    )
    quiz4 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz4,
            ]  
        )
    )
    quiz5 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz5,
            ]  
        )
    )
    quiz6 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz6,
            ]  
        )
    )
    quiz7 = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                quiz7,
            ]  
        )
    )
    
    error = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                error,
            ]  
        )
    )
    win = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                win,
            ]  
        )
    )
#sfondo shop
    container_shop = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                shop,
            ]  
        )
    )
#sfondo search_box
    search_page = f.Container(
        width=360,
        height=800,
        bgcolor=BG,
        border_radius=20,
        content=f.Stack(
            controls=[
                search,
            ]  
        )
    )


#dizionari per muoversi nelle pagine
    pages = {
        '/': f.View(
            "/",
            [
                container
            ],
        ),
        '/create_task': f.View(
            "/create_task",
            [
                container_slide
            ],
        ),
        '/create_task1': f.View(
            "/create_task1",
            [
                container_slide1
            ],
        ),
        
        '/slide_task_2': f.View(
            "/slide_task_2",
            [
                container_slide2
            ],
        ),
        '/slide_task_3': f.View(
            "/slide_task_3",
            [
                container_slide3
            ],
        ),
        '/slide_task_4': f.View(
            "/slide_task_4",
            [
                container_slide4
            ],
        ),
        '/slide_task_5': f.View(
            "/slide_task_5",
            [
                container_slide5
            ],
        ),
        
        '/create_task2': f.View(
            "/create_task2",
            [
                container_game
            ],
        ),
        '/quiz': f.View(
            "/quiz",
            [
                quiz
            ],
        ),
        '/quiz1': f.View(
            "/quiz1",
            [
                quiz1
            ],
        ),
        '/quiz2': f.View(
            "/quiz2",
            [
                quiz2
            ],
        ),
        '/quiz3': f.View(
            "/quiz3",
            [
                quiz3
            ],
        ),
        '/quiz4': f.View(
            "/quiz4",
            [
                quiz4
            ],
        ),
        '/quiz5': f.View(
            "/quiz5",
            [
                quiz5
            ],
        ),
        '/quiz6': f.View(
            "/quiz6",
            [
                quiz6
            ],
        ),
        '/quiz7': f.View(
            "/quiz7",
            [
                quiz7
            ],
        ),
        
        '/error': f.View(
            "/error",
            [
                error
            ],
        ),
        '/win': f.View(
            "/win",
            [
                win
            ],
        ),
        '/create_task3': f.View(
            "/create_task3",
            [
                container_shop
            ],
        ),
        '/search': f.View(
            "/search",
            [
                search_page
            ],
        ),
    }
    def route_change(route):
        page.views.clear()
        page.views.append(
            pages[page.route]
        )
    page.on_route_change = route_change
    page.go(page.route)

f.app(target=main)
